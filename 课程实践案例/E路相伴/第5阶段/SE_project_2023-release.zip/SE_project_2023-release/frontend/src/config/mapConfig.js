export const MapKey="6eefde9e350c9392e70bdf14f66fcfaa"

export const MapSecretKey='6eb2566e8d90747b180cbb7c43e24641'