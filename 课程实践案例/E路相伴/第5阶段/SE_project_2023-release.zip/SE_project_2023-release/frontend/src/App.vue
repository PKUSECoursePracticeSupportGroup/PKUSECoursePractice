<script setup>
import HelloWorld from './components/HelloWorld.vue'
import router from './router';

</script>

<template>
  <div>
    <router-view/>
  </div>
</template>