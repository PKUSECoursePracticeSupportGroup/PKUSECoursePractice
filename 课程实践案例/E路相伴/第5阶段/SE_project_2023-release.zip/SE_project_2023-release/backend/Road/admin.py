from django.contrib import admin
from .models import Road, Point

# Register your models here.
admin.site.register(Road)
admin.site.register(Point)