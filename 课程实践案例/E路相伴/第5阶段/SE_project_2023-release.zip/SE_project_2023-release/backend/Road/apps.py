from django.apps import AppConfig


class RoadConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Road'
